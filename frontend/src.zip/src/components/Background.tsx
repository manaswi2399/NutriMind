import React from 'react';
import './Background.css';

type Variant = 'home' | 'diet' | 'ingredients' | 'favorites';

const Background: React.FC<{ variant?: Variant }> = ({ variant = 'home' }) => {
  return (
    <div className={`background bg-variant-${variant}`} aria-hidden>
      <div className="blob b1" />
      <div className="blob b2" />
      <div className="blob b3" />
      <div className="sparkle s1" />
      <div className="sparkle s2" />
    </div>
  );
};

export default Background;
